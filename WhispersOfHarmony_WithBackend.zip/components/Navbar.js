import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Navbar() {
  const { user, signInWithGoogle, signOutUser } = useAuth();

  return (
    <nav className="flex justify-between items-center bg-white shadow px-4 py-2">
      <Link to="/" className="text-xl font-bold text-blue-700">Whispers of Harmony</Link>
      <div className="space-x-4">
        <Link to="/journal">Journal</Link>
        <Link to="/feed">Feed</Link>
        <Link to="/wallet">Wallet</Link>
        {user ? (
          <>
            <Link to={`/profile/${user.uid}`}>Profile</Link>
            <button onClick={signOutUser}>Sign Out</button>
          </>
        ) : (
          <button onClick={signInWithGoogle}>Sign In</button>
        )}
      </div>
    </nav>
  );
}
