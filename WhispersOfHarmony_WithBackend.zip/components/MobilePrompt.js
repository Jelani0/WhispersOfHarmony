import React from 'react';

export default function MobilePrompt() {
  return (
    <div className="sm:hidden text-center p-2 bg-yellow-100 text-yellow-800">
      For a better experience, use a larger screen or install as a PWA from your browser.
    </div>
  );
}
