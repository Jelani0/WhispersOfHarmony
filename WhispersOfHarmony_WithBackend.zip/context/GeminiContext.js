import React, { createContext, useContext } from 'react';

const GeminiContext = createContext();

export function GeminiProvider({ children }) {
  const generateContent = async (prompt) => {
    const response = await fetch('/api/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt }),
    });
    const data = await response.json();
    return data.text;
  };

  return (
    <GeminiContext.Provider value={{ generateContent }}>
      {children}
    </GeminiContext.Provider>
  );
}

export const useGemini = () => useContext(GeminiContext);
