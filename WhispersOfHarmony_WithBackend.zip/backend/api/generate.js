const express = require('express');
const router = express.Router();
const axios = require('axios');

router.post('/', async (req, res) => {
  const { prompt } = req.body;

  try {
    const result = await axios.post('https://generativelanguage.googleapis.com/v1beta/models/text-bison-001:generateText', {
      prompt: { text: prompt },
      temperature: 0.7,
      candidateCount: 1
    }, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer YOUR_API_KEY`
      }
    });

    res.json({ text: result.data.candidates[0].output });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Gemini generation failed' });
  }
});

module.exports = router;
